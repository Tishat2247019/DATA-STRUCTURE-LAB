#include <iostream>
using namespace std;

int main()
{
    int a = 8;
    int b = 8;
    if (5 == 5)
    {
        cout << "Equal" << endl;
    }
    return 0;
}