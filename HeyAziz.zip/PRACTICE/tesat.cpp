#include <iostream>
using namespace std;

int main()
{
    int a[5];
    a[6] = 8;
    cout << a << endl;
    return 0;
}